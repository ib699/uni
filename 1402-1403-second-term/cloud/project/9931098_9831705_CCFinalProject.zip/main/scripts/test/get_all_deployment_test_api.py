import requests
import json

url = 'http://localhost:5000/get_all_deps'

response = requests.post(url)

print(response.text)

