#!/usr/bin/env bash

# install deps
git clone https://github.com/sadegh-msm/hind.git
cd hind
badh master-build.sh


