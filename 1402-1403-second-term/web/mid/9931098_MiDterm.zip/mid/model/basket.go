package model

type Basket struct {
	ID         int64
	User       string
	CreatedAt  string
	UpdatedAt  string
	BasketData string
	Status     string
}
