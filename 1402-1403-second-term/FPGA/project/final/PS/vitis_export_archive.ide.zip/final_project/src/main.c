#include <stdio.h>
#include <stdint.h>
#include "platform.h"
#include "xil_printf.h"

// Define the sizes of the matrix and kernel
#define MATRIX_SIZE 28
#define KERNEL_SIZE 3

// Simulated BRAM addresses
#define BRAM_BASE_ADDR 0x40000000
#define BRAM_SIZE (MATRIX_SIZE * MATRIX_SIZE + KERNEL_SIZE * KERNEL_SIZE + MATRIX_SIZE * MATRIX_SIZE)

// Memory-mapped IO addresses (these would be specific to your hardware)
volatile uint32_t *bram = (uint32_t *)BRAM_BASE_ADDR;
volatile uint32_t *start_flag = (uint32_t *)(BRAM_BASE_ADDR + BRAM_SIZE * sizeof(uint32_t));
volatile uint32_t *done_flag = (uint32_t *)(BRAM_BASE_ADDR + BRAM_SIZE * sizeof(uint32_t) + sizeof(uint32_t));

void fill_array(uint32_t array[MATRIX_SIZE][MATRIX_SIZE], uint32_t value) {
    for (int i = 0; i < MATRIX_SIZE; ++i) {
        for (int j = 0; j < MATRIX_SIZE; ++j) {
            array[i][j] = value;
        }
    }
}

void fill_kernel(uint32_t kernel[KERNEL_SIZE][KERNEL_SIZE], uint32_t value) {
    for (int i = 0; i < KERNEL_SIZE; ++i) {
        for (int j = 0; j < KERNEL_SIZE; ++j) {
            kernel[i][j] = value;
        }
    }
}

void write_to_bram(volatile uint32_t *bram, uint32_t array[MATRIX_SIZE][MATRIX_SIZE], uint32_t kernel[KERNEL_SIZE][KERNEL_SIZE]) {
    int index = 0;
    for (int i = 0; i < MATRIX_SIZE; ++i) {
        for (int j = 0; j < MATRIX_SIZE; ++j) {
            bram[index++] = array[i][j];
        }
    }
    for (int i = 0; i < KERNEL_SIZE; ++i) {
        for (int j = 0; j < KERNEL_SIZE; ++j) {
            bram[index++] = kernel[i][j];
        }
    }
}

void read_from_bram(volatile uint32_t *bram, uint32_t result[MATRIX_SIZE][MATRIX_SIZE]) {
    int index = MATRIX_SIZE * MATRIX_SIZE + KERNEL_SIZE * KERNEL_SIZE;
    for (int i = 0; i < MATRIX_SIZE; ++i) {
        for (int j = 0; j < MATRIX_SIZE; ++j) {
            result[i][j] = bram[index++];
        }
    }
}

void print_matrix(uint32_t matrix[MATRIX_SIZE][MATRIX_SIZE]) {
    for (int i = 0; i < MATRIX_SIZE; ++i) {
        for (int j = 0; j < MATRIX_SIZE; ++j) {
            printf("%10u ", matrix[i][j]);
        }
        printf("\n");
    }
}

int main() {

	init_platform();
    // Create and fill the input matrix and kernel
    uint32_t input_matrix[MATRIX_SIZE][MATRIX_SIZE];
    uint32_t kernel[KERNEL_SIZE][KERNEL_SIZE];
    uint32_t result_matrix[MATRIX_SIZE][MATRIX_SIZE];

    fill_array(input_matrix, 1);  // Example fill value
    fill_kernel(kernel, 1);  // Example fill value

    // Write the input matrix and kernel to BRAM
    write_to_bram(bram, input_matrix, kernel);

    // Set the start flag
    *start_flag = 1;

    // Wait for the done flag
    while (*done_flag == 0);

    // Read the result from BRAM
    read_from_bram(bram, result_matrix);

    // Print the result
    printf("Result Matrix:\n");
    print_matrix(result_matrix);

    cleanup_platform();
    return 0;
}
